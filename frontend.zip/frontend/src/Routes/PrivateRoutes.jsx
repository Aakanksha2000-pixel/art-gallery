import { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import { Outlet } from 'react-router-dom'
import Spinner from '../Components/Layout/Spinner'

const PrivateRoutes = () => {
    const auth = useSelector(state => state.auth)
    const [ok, setOk] = useState(false)
    useEffect(() => {
        const isLoggedIn = async () => {
            const response = await fetch('http://localhost:5000/api/v1/auth/user-auth',{
                headers: {
                    'Authorization': auth?.token
                }
            })
            const res = await response.json()
            if (res.success) setOk(true)
            else setOk(false)
        }
        auth?.token && isLoggedIn()
    }, [auth?.token])
    return ok ? <Outlet /> : <Spinner />
}

export default PrivateRoutes