import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import { Outlet } from 'react-router-dom'
import Spinner from '../Components/Layout/Spinner'

const AdminRoutes = () => {
    const [ok, setOk] = useState(false)
    const auth = useSelector(state => state.auth)

    useEffect(() => {
        const isAdmin = async () => {
            const response = await fetch('http://localhost:5000/api/v1/auth/admin-auth', {
                headers: {
                    'Authorization': auth?.token
                }
            })
            const res = await response.json()
            res.success ? setOk(true) : setOk(false)
        }
        auth?.token && isAdmin()
    }, [auth?.token])
    return ok ? <Outlet /> : <Spinner path="/" />
}

export default AdminRoutes