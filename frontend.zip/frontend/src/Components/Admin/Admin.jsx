import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import NavFooterWrapper from '../Layout/NavFooterWrapper'
import Title from '../Layout/Title'
import Dashboard from '../User/Dashboard'
import style from '../User/Profile.module.css'
import Menu from './Menu'

const Admin = () => {
  const [user, setUser] = useState({})
  const auth = useSelector(state => state.auth)

  useEffect(() => {
    setUser(auth?.user)
  }, [auth?.user])

  return (
    <>
      <NavFooterWrapper>
        <div className={`${style.profile}`}>
          <div className='container-fluid mt-5'>
            <div className={`row ${style.user_profile} align-items-start`}>
              <div className='col-lg-4 d-flex justify-content-center'>
                <Menu />
              </div>
              <div className={`col-lg-8 ${style.account}`}>
                <Dashboard name={user.name} email={user.email} address={user.address} phone={user.phone} />
              </div>
            </div>
          </div>
        </div >
      </NavFooterWrapper>
    </>
  )
}

export default Admin