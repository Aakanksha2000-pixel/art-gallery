import React, { useEffect, useRef, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { toast } from 'react-toastify'
import { getCategories } from '../../Store/category-reducer'
import NavFooterWrapper from '../Layout/NavFooterWrapper'
import Menu from './Menu'

const ProductForm = () => {
  const cat = useSelector(state => state.category)
  const auth = useSelector(state => state.auth)
  const [items, setItems] = useState([])
  const title = useRef()
  const dispatch = useDispatch()

  useEffect(() => {
    (async () => {
      const result = await dispatch(getCategories(auth?.token))
      !result ? toast.error('Error while fetching categorires') : setItems(result)
    })()
  }, [])

  const submitHandler = (e) => {
    e.preventDefault()
  }

  return (
    <NavFooterWrapper>
      <div className='container-fluid pt-5'>
        <div className='row mt-5'>
          <div className='col-lg-2'>
            <Menu />
          </div>
          <div className='col-lg-10'>
            <div className='container'>
              <h5 className='mt-2'>Create Product</h5>
              <form className='p-4 bg-light shadow-sm' onSubmit={submitHandler}>
                <div className="d-flex">
                  <div className="input-box d-flex flex-column my-3 w-100 m-1">
                    <span className="6details">Title</span>
                    <input className='form-control' ref={title} type="text" placeholder="Product Title" required />
                  </div>
                  <div className="input-box d-flex flex-column my-3 w-100 m-1">
                    <span className="details">Description</span>
                    <input className='form-control' ref={title} type="text" placeholder="Product Description" required />
                  </div>
                </div>
                <div className="d-flex">
                  <div className="input-box d-flex flex-column my-3 w-100 m-1">
                    <span className="details">Price</span>
                    <input className='form-control' ref={title} type="text" placeholder="Product Price" required />
                  </div>
                  <div className="input-box d-flex flex-column my-3 w-100 m-1">
                    <span className="details">Rating</span>
                    <input className='form-control' ref={title} type="text" placeholder="Product Rating" required />
                  </div>
                  <div className="input-box d-flex flex-column my-3 w-100 m-1">
                    <span className="details">Stock</span>
                    <input className='form-control' ref={title} type="text" placeholder="Product Stock" required />
                  </div>
                </div>
                <div className="d-flex">
                  <div className="input-box d-flex flex-column my-3 w-100 m-1">
                    <span className="details">Category</span>
                    <select className='form-select' ref={title} type="text" placeholder="Product Category" required>
                      {items?.map(item => <option value={item.name}>{item.name}</option>)}
                    </select>
                  </div>
                  <div className="input-box d-flex flex-column my-3 w-100 m-1">
                    <span className="details">Thumbnail</span>
                    <input className='form-control' ref={title} type="file" placeholder="Product Thumbnail" required />
                  </div>
                </div>
                <div className='d-flex justify-content-center mt-3'>
                  <button className='btn btn-dark w-25'>Create</button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </NavFooterWrapper>
  )
}
export default ProductForm