import React, { useEffect, useRef, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { categoryActions, createCategory, deleteCategory, getCategories, updateCategory } from '../../Store/category-reducer'
import NavFooterWrapper from '../Layout/NavFooterWrapper'
import Menu from './Menu'
import style from './style.module.css'
import { toast } from 'react-toastify'
import Loader from '../UI/Loader'
import Dialog from '../Modal/Dialog'
import { AiTwotoneDelete } from 'react-icons/ai'
import { AiTwotoneEdit } from 'react-icons/ai'
import { Link, useParams } from 'react-router-dom'

const Category = () => {
  const [items, setItems] = useState([])
  const [dialog, setDialog] = useState(false)
  const [item, setItem] = useState({})
  const category = useRef()
  const dispatch = useDispatch()
  const params  = useParams()
  const auth = useSelector(state => state.auth)
  const cat = useSelector(state => state.category)

  const fetchCategory = async () => {
      dispatch(categoryActions.setLoader())
      const result = await dispatch(getCategories(auth?.token))
      !result ? toast.error('Error while fetching categorires') : setItems(result)
      dispatch(categoryActions.setLoader())
  }

  useEffect(() => {
    fetchCategory()
  }, [])

  const submitHandler = async (e) => {
    e.preventDefault()
    const response = await dispatch(createCategory(auth?.token, { name: category.current.value }))
    fetchCategory()
    response ? toast.success('category created successfully') : toast.error('error while creating category')
  }

  const updateHandler = async(data) => {
    const res = await dispatch(updateCategory(auth?.token, params.id, data))
    res.success ? toast.success(res.msg) : toast.error(res.err)
    fetchCategory()
  }

  const deleteHandler = async () => {
    const response = await dispatch(deleteCategory(auth?.token, params.id))
    response.success ? toast.success(response.message) : toast.error(response.err) 
    fetchCategory()
  }

  return (
    <NavFooterWrapper>
      <div className='container-fluid pt-5'>
        <div className='row mt-5'>
          <div className='col-lg-2'>
            <Menu />
          </div>
          <div className='col-lg-10 bg-light p-4'>
            <form className='p-4 bg-white shadow-sm w-50 mx-auto' onSubmit={submitHandler}>
              <div className="input-box d-flex flex-column justify-content-center align-items-center my-3 m-1">
                <span className="details my-2">Category Name</span>
                <input className='form-control w-50 text-center' ref={category} type="text" placeholder="Product Category" required />
              </div>
              <div className='d-flex justify-content-center mt-3'>
                <button className='btn bg-dark text-light w-25'>Create</button>
              </div>
            </form>
            <div className='d-flex justify-content-center mt-4'>
              <table className={`table table-striped table-bordered w-50 ${style.table}`}>
                <thead>
                  <tr>
                    <th>Category Name</th>
                    <th>Update</th>
                    <th>Delete</th>
                  </tr>
                </thead>
                <tbody>
                  {items?.map(item => (
                    <tr key={item._id}>
                      <td><h6>{item.name}</h6></td>
                      <td className='text-center update'><Link to={`/authorized/admin/category/${item._id}`} onClick={() => {
                        setItem({id: item._id, name: item.name})
                        setDialog(!dialog)
                      }}><AiTwotoneEdit /></Link></td>
                      <td className='text-center delete'><Link to={`/authorized/admin/category/${item._id}`} onClick={deleteHandler}><AiTwotoneDelete /></Link></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {cat.loader && <Loader />}
            {dialog && <Dialog title='Update Category' name={item.name} id={item.id} btnTitle='update' setDialogFun={() => setDialog(!dialog)} update={(data) => updateHandler(data)} />}
          </div>
        </div>
      </div>
    </NavFooterWrapper>
  )
}

export default Category