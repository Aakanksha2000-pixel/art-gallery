import { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getProducts, productActions } from '../../Store/product-reducer'
import NavFooterWrapper from '../Layout/NavFooterWrapper'
import Menu from './Menu'
import { toast } from 'react-toastify'
import style from './style.module.css'
import Loader from '../UI/Loader'
import {AiTwotoneDelete} from 'react-icons/ai'
import {AiTwotoneEdit} from 'react-icons/ai'
import { Link } from 'react-router-dom'

const Products = () => {
  const [items, setItems] = useState([])
  const product = useSelector(state => state.product)
  const auth = useSelector(state => state.auth)
  const dispatch = useDispatch()

  useEffect(() => {
    (async () => {
      dispatch(productActions.setLoader())
      const result = await dispatch(getProducts(auth?.token))
      !result ? toast.error('Error while fetching products') : setItems([...result])
      dispatch(productActions.setLoader())
    })()
  }, [])

  return (
    <NavFooterWrapper>
      <div className='container-fluid pt-5'>
        <div className='row mt-5'>
          <div className='col-lg-2'>
            <Menu />
          </div>
          <div className='col-lg-10'>
            <table className={`table table-striped table-bordered ${style.table}`}>
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Title</th>
                  <th>Description</th>
                  <th>Price</th>
                  <th>Rating</th>
                  <th>Stock</th>
                  <th>Category</th>
                  <th>Thumbnail</th>
                  <th>Update</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                {items?.map(item => (
                  <tr key={item.id}>
                    <td>{item.id}</td>
                    <td>{item.title}</td>
                    <td>{item.description}</td>
                    <td>{item.price}</td>
                    <td>{item.rating}</td>
                    <td>{item.stock}</td>
                    <td>{item.category}</td>
                    <td><img src={item.thumbnail} alt='painting' className='img-fluid' /></td>              
                    <td className='text-center update'><Link to={`/authorized/admin/category/${item._id}`}><AiTwotoneEdit /></Link></td>
                    <td className='text-center delete'><Link to={`/authorized/admin/category/${item._id}`}><AiTwotoneDelete /></Link></td>
                  </tr>
                ))}
              </tbody>
            </table>
            {product.loader && <Loader />}
          </div>
        </div>
      </div>
    </NavFooterWrapper>
  )
}

export default Products