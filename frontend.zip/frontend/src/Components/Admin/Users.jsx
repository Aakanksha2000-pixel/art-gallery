import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getUsers, userActions } from '../../Store/user-reducer'
import NavFooterWrapper from '../Layout/NavFooterWrapper'
import Menu from './Menu'
import { toast } from 'react-toastify'
import Loader from '../UI/Loader'
import {AiTwotoneDelete} from 'react-icons/ai'
import {AiTwotoneEdit} from 'react-icons/ai'

const Users = () => {
  const [users, setUsers] = useState([])
  const dispatch = useDispatch()
  const user = useSelector(state => state.user)

  useEffect(() => {
    (async () => {
      dispatch(userActions.setLoader())
      const response = await dispatch(getUsers())
      !response ? toast.error('error while fetching users!') : setUsers([...response])
      dispatch(userActions.setLoader())
    })()
  }, [])

  return (
    <NavFooterWrapper>
      <div className='container-fluid pt-5'>
        <div className='row mt-5'>
          <div className='col-lg-2'>
            <Menu />
          </div>
          <div className='col-lg-10'>
            <table className={`table table-striped table-bordered`}>
              <thead>
                <tr>
                  <th>Users</th>
                  <th>Email</th>
                  <th>Gender</th>
                  <th>Phone</th>
                  <th>Address</th>
                  <th>Update</th>
                  <th>Delete</th>
                </tr>
              </thead>
              <tbody>
                {users?.map(item => (
                  <tr key={item._id}>
                    <td>{item.name}</td>
                    <td>{item.email}</td>
                    <td>{item.gender}</td>
                    <td>{item.phone}</td>
                    <td>{item.address}</td>
                    <td className='text-center update'><AiTwotoneEdit /></td>
                    <td className='text-center delete'><AiTwotoneDelete /></td>
                  </tr>
                ))}
              </tbody>
            </table>
            {user.loader && <Loader />}
          </div>
        </div>
      </div>
    </NavFooterWrapper>
  )
}

export default Users