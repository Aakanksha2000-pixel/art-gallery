import React from 'react'
import { useDispatch } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { authActions } from '../../Store/auth-reducer'
import style from '../User/Profile.module.css'

const Menu = () => {
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const logoutHandler = () => {
    dispatch(authActions.logoutHandler())
    navigate('/login')
  }
  return (
    <>
      <table className='table table-bordered table-striped'>
        <tbody>
          <tr><td className={`p-2 ${style.profile_link}`} ><Link to='/authorized/admin/profile'>Dashboard</Link></td></tr>
          <tr><td className={`p-2 ${style.profile_link}`} ><Link to='/authorized/admin/category'>Category</Link></td></tr>
          <tr><td className={`p-2 ${style.profile_link}`} ><Link to='/authorized/admin/create-product'>Create Product</Link></td></tr>
          <tr><td className={`p-2 ${style.profile_link}`} ><Link to='/authorized/admin/products'>Products</Link></td></tr>
          <tr><td className={`p-2 ${style.profile_link}`} ><Link to='/authorized/admin/users'>Users</Link></td></tr>
          <tr><td className={`p-2 ${style.profile_link}`} onClick={logoutHandler}>Logout</td></tr>
        </tbody>
      </table>
    </>
  )
}

export default Menu