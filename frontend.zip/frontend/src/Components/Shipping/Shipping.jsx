import React from 'react'
import style from './Shipping.module.css'
import img from '../../assets/img/nav--poster--1.jpeg'

const Shipping = () => {
    return (
        <div className='container-fluid'>
            <div className='row'>
                <div className={`col-lg-6 ${style.first_half}`}>
                    <div className='container-fluid'>
                        <div className={`${style.main_box}`}>
                            <h1 className='logo mt-5 mb-4' >- Art Corner -</h1>
                            <div className={style.form_box}>
                                <h3 className={style.heading}>Shipping address</h3>
                                <div className='row'>
                                    <div className='col-lg-12 col-sm-12'>
                                        <form>
                                            <div className={style.input_box}>
                                                <input type='text' placeholder='First name' />
                                                <input type='text' placeholder='Last name' />
                                            </div>
                                            <div>
                                                <input type='email' placeholder='Email' />
                                            </div>
                                            <div>
                                                <input type='text' placeholder='Phone' />
                                            </div>
                                            <div className={style.address}>
                                                <input type='text' placeholder='Address' />
                                                <input type='text' placeholder='Apartment, suite, etc. (optional)' />
                                            </div>
                                            <div className={style.input_box}>
                                                <input type='text' placeholder='City' />
                                                <select>
                                                    <option>State</option>
                                                    <option>Madhya Pradesh</option>
                                                    <option>Maharashtra</option>
                                                    <option>Gujarat</option>
                                                    <option>Assam</option>
                                                </select>
                                                <input placeholder='PIN code' />
                                            </div>
                                            <div>
                                                <input type='file' />
                                            </div>
                                            <div><button className='btn btn-primary px-4 my-4'>Continue Shipping</button></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='col-lg-6 mt-5'>
                    <div className={`${style.second_half}`}>
                        <table className='table mt-5'>
                            <tbody>
                                <tr className={style.tr}>
                                    <td>
                                        <div className={style.product} >
                                            <img src={img} alt='cart item' />
                                            <h3>Buddha Poster</h3>
                                        </div>
                                    </td>
                                    <td><h3 className={style.price}>Rs. 4512</h3></td>
                                </tr>
                            </tbody>
                        </table>
                        <table className='table mt-3'>
                            <tbody>
                                <tr className={style.trs}>
                                    <td>
                                        <h3>Subtotal:</h3>
                                    </td>
                                    <td><h3 className={style.price}>Rs. 4512</h3></td>
                                </tr>
                                <tr className={style.trs}>
                                    <td>
                                        <h3>Estimated taxes:</h3>
                                    </td>
                                    <td><h3 className={style.price}>Rs. 4512</h3></td>
                                </tr>
                                <tr className={style.trs}>
                                    <td>
                                        <h3>Total:</h3>
                                    </td>
                                    <td><h3 className={style.price}>Rs. 4512</h3></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Shipping