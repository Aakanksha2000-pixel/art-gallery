import { useState, useContext } from 'react'
import { cartContext } from '../../Context/cart-context';
import { wishContext } from '../../Context/wishlist-context'
import Dropdown from './Dropdown';
import CartModal from '../Modal/CartModal';
import WishlistModal from '../Modal/WishlistModal';
import style from './Navigation.module.css'
import './Nav.css'
import nav_poster_1 from '../../assets/img/nav--poster--1.jpeg'
import nav_poster_2 from '../../assets/img/nav--poster--2.jpeg'
import { FiShoppingCart } from "react-icons/fi";
import { TfiHeart } from "react-icons/tfi";
import { BiUser } from "react-icons/bi";
import { BsSearch } from "react-icons/bs";
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import '../../../node_modules/bootstrap/dist/css/bootstrap.css'
import '../../../node_modules/bootstrap/dist/js/bootstrap.bundle.js'
import Search from '../UI/Search';

export default function Navigation() {
    const [isPaintDropdown, setIsPaintDropdown] = useState(false)
    const [isDrawingDropdown, setIsDrawingDropdown] = useState(false)
    const cart_ctx = useContext(cartContext)
    const wish_ctx = useContext(wishContext)
    const auth = useSelector(state => state.auth)

    function setPaintings() {
        setIsPaintDropdown(!isPaintDropdown)
        setIsDrawingDropdown(false)
    }
    function setDrawings() {
        setIsDrawingDropdown(!isDrawingDropdown)
        setIsPaintDropdown(false)
    }

    return (
        <>
            <header className='position-fixed w-100 shadow-lg'>
                <div className='container-fluid'>
                    <nav className="navbar navbar-expand-lg navbar-light position-relative">
                        <div className="container-fluid">
                            <Link to='/'><h1 className={style.navbar_brand}>-Art Corner-</h1></Link>
                            <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                <span className="navbar-toggler-icon"></span>
                            </button>
                            <div className="collapse navbar-collapse justify-content-around" id="navbarSupportedContent">
                                <ul className={`navbar-nav mb-2 mb-lg-0 ${style.navbar}`}>
                                    <Link to='/collections'>
                                        <li className={`nav-item ${style.active}`}>
                                            all artwork
                                        </li>
                                    </Link>
                                    <li className="nav-item" onClick={setPaintings}>
                                        paintings
                                    </li>
                                    <li className="nav-item" onClick={setDrawings} >
                                        drawings
                                    </li>
                                    <Link to='/blogs'>
                                        <li className="nav-item">
                                            blogs
                                        </li>
                                    </Link>
                                    <Link to='/dashboard/user/sell-paintings'>
                                        <li className="nav-item">
                                            sell paintings
                                        </li>
                                    </Link>
                                </ul>
                                <ul className={`navbar mb-2 mb-lg-0 ${style.nav_icons}`}>
                                    {auth?.user?.role === 0 && <h5 type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"><BsSearch /></h5>}

                                    {auth?.user?.role === 0 && <h5 className={style.heart_svg} onClick={wish_ctx.ToggleFunction}><TfiHeart /><span>{wish_ctx.totalQuantity}</span></h5>}

                                    {auth?.user?.role === 0 && <h5 className={style.cart_svg} onClick={cart_ctx.ToggleFunction}><FiShoppingCart /><span>{cart_ctx.totalQuantity}</span></h5>}

                                    {auth.token && <Link to={`/${auth?.user?.role === 1 ? 'authorized/admin' : 'dashboard/user'}/profile`}><h5 className='nav-item profile-logo'><BiUser /></h5></Link>}
                                    {
                                        !auth.token && (
                                            <>
                                                <h5 className="nav-item dropdown profile-logo">
                                                    <a className="nav-link dropdown-toggle" href="abab" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                                        <BiUser />
                                                    </a>
                                                    <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
                                                        <li><Link className="dropdown-item" to="/login">Login</Link></li>
                                                        <li><Link className="dropdown-item" to="/register">Register</Link></li>
                                                    </ul>
                                                </h5>
                                            </>
                                        )
                                    }
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
            </header>
            {isPaintDropdown && (
                <Dropdown src={nav_poster_1} menu='Paintings' menuList={['Abstract Paintings', 'Cityscape Paintings', 'Landscape Paintings']} onClick={setPaintings} />
            )}
            {isDrawingDropdown && (
                <Dropdown src={nav_poster_2} menu='Drawings' menuList={['Sketch', 'Modern Drawings', 'Buddha Drawings']} onClick={setDrawings} />
            )}
            {cart_ctx.modalIsOpen && (
                <CartModal />
            )}
            {wish_ctx.modalIsOpen && (
                <WishlistModal />
            )}
            <Search class='offcanvas offcanvas-end' />
        </>
    )
}