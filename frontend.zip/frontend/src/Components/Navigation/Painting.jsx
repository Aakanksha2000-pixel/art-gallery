import { useContext, useEffect, useState } from 'react'
import NavFooterWrapper from '../Layout/NavFooterWrapper';
import { useParams } from 'react-router-dom';
import { filterContext } from '../../Context/filter-context';
import { cartContext } from '../../Context/cart-context';
import { wishContext } from '../../Context/wishlist-context';
import {toast} from 'react-toastify';

const Painting = ()=>{
    const params = useParams()
    const [painting, setPainting] = useState('')
    const ctx = useContext(filterContext)
    const cart_ctx = useContext(cartContext)
    const wish_ctx = useContext(wishContext)

     const addCartItemHandler = (item) => {
        cart_ctx.addItem({
            ...item,
            quantity: 1,
            totalPrice: item.price
        })
        toast.success('Painting added to cart successfully!')
    }
    const wishlistHandler = (item) => {
        wish_ctx.addItem(item)
        toast.success('Painting added to wishlist successfully!')
    }

    useEffect(() => {
        const _id = params.id
        const item =  ctx.items.filter(item => item._id === _id)
        // console.log(item)
        setPainting(item[0])
    }, [params.id])
	return (
		<NavFooterWrapper>
			<section className='bg-light py-2'>
				<div className='container-fluid pt-5'>
					<div className='row mt-5 p-5' style={{background: 'white'}}>
						<div className='col-lg-8 d-flex justify-content-center'>
							<img src={painting?.thumbnail} alt='painting' className='img-fluid' />
						</div>
						<div className='col-lg-4 d-flex justify-content-start'>
							<div className='box'>
								<h5 style={{letterSpacing: '.2rem'}}>{painting?.title}</h5>
								<p style={{ color: 'grey'}}>{painting?.description}</p>
								<hr />
								<p className='mb-3'>Shipping calculated at checkout.</p>
								<h6 style={{fontSize: '1.8rem', color: 'grey'}}>Rs. {painting?.price}</h6>
								<p style={{color: 'green', fontWeight: 'bold'}}>Rating: {painting?.rating}</p>
								<div className='d-flex flex-column'>
									<button className='btn button w-100 mb-2' onClick={() => wishlistHandler(painting)}>Add to wishlist</button>
									<button className='btn bg-dark text-light w-100' onClick={() => addCartItemHandler(painting)}>Add to cart</button>
								</div>
								<div className='d-flex flex-column mt-3'>
									<h6 style={{fontWeight: 'bold'}}>Return policy :</h6>
									<p style={{ color: 'grey'}}>7 days applicable from delivery date.</p>
								</div>
							</div>
						</div>
					</div>
			</div>
			</section>
		</NavFooterWrapper>
	)
}

export default Painting