import React, { useContext, useEffect, useState } from 'react'
import { filterContext } from '../../Context/filter-context'
import { Link } from 'react-router-dom';

const Search = (props) => {
    const [search, setSearch] = useState(null)
    const ctx = useContext(filterContext)
    const [result, setResult] = useState([])

    const searchHandler = (e) => {
        setSearch(e.target.value)
    }

    useEffect(() => {
        let reg = new RegExp(search, 'gi')
        // console.log(reg)
        if (search) {
            const newArray = ctx.items.filter(item => reg.test(item.title))
            console.log(newArray)
            setResult([...newArray])
        }
        else setResult([])
    }, [search, ctx.items])

    return (
        <>
            <div className={props.class} tabIndex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">
                <div className="offcanvas-header">
                    <h5 id="offcanvasRightLabel" className='h5'>Search our site</h5>
                    <button type="button" className="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div className="offcanvas-body">
                    <div className='shadow-sm mb-4'>
                        <form>
                            <input type='text' className='form-control w-100' onChange={searchHandler} />
                        </form>
                    </div>
                    <hr/>
                    <div className='search-result container'>
                        <div className='row'>
                            {
                                result?.map(item => (
                                    <Link to={`/collections/${item._id}`}>
                                        <div className='col-12 shadow-sm mb-3' key={item._id}>
                                            <div className='row p-2'>
                                                <div className='col-lg-5'>
                                                    <img src={item.thumbnail} className='img-fluid' alt='painting' />
                                                </div>
                                                <div className='col-lg-7'>
                                                    <h6 style={{fontWeight: 600, marginBottom: '0 !important', color: '#4d5959'}} >{item.title}</h6>
                                                    <p style={{color: 'grey', fontSize: '10pt'}}>Rs.{item.price}</p>
                                                </div>
                                            </div>
                                        </div>
                                    </Link>
                                ))
                            }
                            {result.length === 0 && <h5 className='text-center'>No result found!</h5>}
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Search