import { useState } from 'react';
import './Contact.css'
import photo from "../../assets/img/location.png";
import phone from "../../assets/img/phone.png";
import email from "../../assets/img/mail.png";

const Contact = () => {
    const [data, setdata] = useState({
        name: "",
        email: "",
        message: "",
    });

    const handleChange = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        setdata({ ...data, [name]: value })
    };

    const handleSubmit = async (e) => {
        e.preventDefault()
        alert("Form Submitted SuccessFully")
    };

    return (
        <section className='contact-section pt-5'>
            <div className='main mt-3'>
                <div className='head fw-bold fm-2 py-5'>
                    <h1 className='heading'>Contact US</h1>
                </div>

                <div className='container con2 mt-5'>
                    <div className='row'>
                        <div className='col-lg-2'></div>
                        <div className='col-lg-7'>
                            <div className='send pl-3'>
                                <h1 className='fw-bold fs-3 px-4'>Send us a message</h1>
                            </div>
                            <div className='sendpara'>
                                <p className='px-4'>
                                    We appreciate your feedback! Please tell us how is your experience on our
                                    website by filling out this form.
                                </p>
                            </div>
                        </div>
                        <div className='col-lg-2'></div>
                    </div>

                </div>
                <div className='container'>

                    <form className='needs-validation' method='post' onSubmit={handleSubmit}>
                        <div className='form-group'>
                            <label className='form-label'>Full Name</label>
                            <input name="name" type='text' className='form-control' id=''
                                onChange={handleChange} value={data.name} placeholder='Enter Name' required />

                        </div>
                        <div className='form-group'>
                            <label className='form-label'>Email</label>
                            <input name="email" type='email' className='form-control' id=''
                                onChange={handleChange} value={data.email} placeholder='example@gmail.com' required />

                        </div>
                        <div className='form-group'>
                            <label className='form-label'>Phone Number:</label>
                            <input name="phone" type='number' className='form-control' id=''
                                onChange={handleChange} value={data.phone} placeholder='+91-XXXXXXXXXX' required />

                        </div>
                        <div className='form-group '>
                            <label className='form-label'>Details:</label>
                            <textarea name="message" type="text" className='form-control' cols='20' rows='4' id=''
                                value={data.message} onChange={handleChange}
                                placeholder='Type Your Message Here...' required /><br />

                        </div>
                        <button className='btn button'>Submit</button>

                    </form>
                </div>

                <div className='container lastc'>
                    <div className='row contact--box'>
                        <div className='col-lg-3 address'>
                            <div className='imgTag'>
                                <img alt='' src={photo} />
                            </div>
                            <div className='ahead'>
                                <h1 className=''>Address</h1>
                                <h6>Nh3,Mhow</h6>
                                <h6>Indore MP09</h6>
                            </div>
                        </div>
                        <div className='col-lg-3 address'>
                            <div className='imgTag'>
                                <img alt='' src={phone} />
                            </div>
                            <div className='ahead'>
                                <h1 className='fw-bold fs-4'>Phone</h1>
                                <h6>+91-0000000000</h6>
                                <h6>+91-0000000000</h6>
                            </div>
                        </div>
                        <div className='col-lg-3 address'>
                            <div className='imgTag'>
                                <img alt='' src={email} />
                            </div>
                            <div className='ahead'>
                                <h1 className='fw-bold fs-4'>Email</h1>
                                <h6>artCorner@gmail.com</h6>
                                <h6>info.artcorner@co.in</h6>
                            </div>
                        </div>
                    </div>
                </div>
                <div><p></p></div>
            </div>
        </section>
    )
}

export default Contact
