// import React, { Component } from 'react';
// import art1 from '../Component/art1.jpg';
import style from './About.module.css'

export default function About() {
  return (
    <section className={style.section}>
      <div className={style.about_box}>
        <h1 className={style.heading} >About Us</h1>
      </div>

      <div className='container mt-5'>
        <p>
          <i className={style.italic}>
            As Henry Matisse said, “Creativity takes courage” and Edward Hopper claimed, “if I could say it in words there would be no reason to paint”, it is evident that art is a wonderful and strange thing.
          </i>
          <br />
          <br />

          The reflection of thoughts and representation of ideas, art is something to which everyone can connect. Artists and art lovers are the ones who form this magical amalgamation through art. Art Corner aims to bring these thoughts and ideas together by connecting the leading artists and art lovers on a single platform. With the idea of providing artists with a platform where they can showcase and sell their art while the art lovers can have high-quality and modern artwork accessible, Art Corner offers a wide collection of paintings, drawings, handicrafts and artworks.<br /><br />

          We have created a platform where artists can freely express their thoughts and ideas through magnificent paintings. From abstract paintings and modern art paintings to Radha Krishna and Buddha paintings, you can get a wide collection of different types of paintings at Art Corner. We strive to put forth an exclusive assortment of paintings for you to explore.</p>
        <br />
        <p className={style.mission_vision}>Mission</p>
        <p>At Art Corner, we work with the mission:</p>
        <ul>
          <li>To become a global platform for artists and art lovers from across the world to come together and express their talent and appreciation for art</li>
          <li>To encourage and appreciate the understanding for art and present stupendous artworks at all times</li>
        </ul>
        <p className={style.mission_vision}>Vision</p>
        <ul>
          <li>
            To shape and enrich the quality of artworks we present on our platform and to become an acclaimed name in the area while supporting all the global artists with us always
          </li>
        </ul>
        <p className={style.mission_vision}>Why Choose Us?</p>
        <p>We have emerged as a trusted platform where you can get exceptional paintings from the leading and talented artists across the world. Well, that is not all, we have a lot to offer to you that would make you choose us always.</p>
        <ul>
          <li>Artists and art lovers from all across the globe can choose to sell and buy artworks on Art Corner</li>
          <li>A wide range and collection of paintings for you to explore, sell and buy</li>
          <li>Verified Artists on the platform can upload and send any number of paintings as they want</li>
          <li>We are a highly trusted and leading art platform where every artist and art lover is cherished</li>
          <li>Drawings, paintings, stencils, posters, handicrafts and more, we have a splendid range for you to get your hands on</li>
          <li>Different kinds of artworks on different types of materials and surfaces are available for you to choose from as our artists have the liberty to create whatever they feel the best</li>
          <li>Exceptional customer service and support in case you get stuck anywhere throughout the process</li>
          <li>A network of globally leading and acclaimed artists that contribute their masterpieces to our collection</li>
        </ul>
        <p>No complicated formalities or no complex steps, all you have to do is browsing our collection and make it yours in a few simple steps. Authentic artworks and magnificent creations, you can make them yours with Art Corner.</p>

      </div>
    </section>
  )
}