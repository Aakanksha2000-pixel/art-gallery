import { useRef, useContext } from 'react'
import { filterContext } from '../../Context/filter-context';
import './Filter.css'

export default function Filter() {
    const priceref = useRef()
    const categoryref = useRef()
    const filter_ctx = useContext(filterContext)

    function priceFilterHandler() {
        filter_ctx.filterByPrice(priceref.current.value)
    }
    function categoryFilterHandler() {
        console.log(categoryref.current.value)
        filter_ctx.filterByCategory(categoryref.current.value)
    }

    return (
        <div className='container-fluid Filter_Box'>
            <div className="row">
                <div className='col-12 box'>
                    <h5 className="widget-title">By Price</h5>
                    <select ref={priceref} onChange={priceFilterHandler} >
                        <option value={[1000, 9999]} > Rs. 1000 — Rs. 9,999 </option>
                        <option value={[10000, 19999]} > Rs. 10,000 — Rs. 19,999 </option>
                        <option value={[20000, 29999]} > Rs. 20,000 — Rs. 29,999 </option>
                        <option value={[30000, 39999]} > Rs. 30,000 — Rs. 39,999 </option>
                        <option value={[40000, 49999]} > Rs. 40,000 — Rs. 49,999 </option>
                        <option value={[50000, 59999]} > Rs. 50,000 — Rs. 59,999 </option>
                        <option value={[60000, 69999]} > Rs. 60,000 — Rs. 69,999 </option>
                        <option value={[70000, 79999]} > Rs. 70,000 — Rs. 79,999 </option>
                    </select>
                </div>
                <div className='col-12 box'>
                    <h5 className="widget-title">By Category</h5>
                    <select ref={categoryref} onChange={categoryFilterHandler} >
                        <option value='Abstract Paintings'> Abstract Paintings </option>
                        <option value='Cityscape Paintings'> Cityscape Paintings </option>
                        <option value='Landscape Paintings'>Landscape Paintings</option>
                        <option value='Sketch'> Sketch </option>
                        <option value='Modern Drawings'> Modern Drawings </option>
                        <option value='Buddha Drawings '> Buddha Drawings </option>
                    </select>
                </div>
            </div>
        </div>
    )
}