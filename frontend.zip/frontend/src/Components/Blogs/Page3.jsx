import style from './Blog.module.css'

export default function Page3() {
    return (
        <section className={style.section}>
            <div className={style.page5}>
                <h5>AN INTRODUCTION TO DIFFERENT PAINTING MEDIUMS</h5>
                <p class="pg1"><i>February 10, 2023</i></p>
                <p class="pg1"> In blog 0 comment</p>
            </div><br />
            <div className="container">
                <p class="para">When it comes to creating a work of art, the medium used by the artist is just as important as the subject matter and style. Different painting mediums have unique qualities and textures that can greatly impact the look and feel of a piece. Whether you're a collector, an artist, or just an art enthusiast, understanding the different painting mediums is an essential part of appreciating and buying art.</p>

                <p className="para">Here's an introduction to some of the most popular painting mediums</p>

                <p className="para"><b>Oil Paint:</b> Oil paint is a slow-drying medium that is highly versatile and favored by many artists for its rich, luminous colors and ability to create deep, textured surfaces. Oil paintings can take many forms, from photorealistic portraits to abstract expressionist works, and the medium's versatility allows for great creative freedom.</p>

                <p className="para"><b>Acrylic Paint:</b> Acrylic paint is a water-based medium that dries quickly and has a plastic-like finish. This makes it a popular choice for artists who want to create bold, bright, and vibrant works. Unlike oil paint, acrylic paint cannot be easily blended or layered, but it is a more affordable and convenient option for artists who work in a fast-paced environment.</p>

                <p className="para"><b>Watercolor Paint:</b> Watercolor paint is a transparent, water-based medium that is prized for its delicate, ethereal quality. It is often used to create beautiful, atmospheric landscapes, but can also be used for more abstract pieces. Watercolor paintings can be created on paper, canvas, or other surfaces, and they are often used in conjunction with other mediums, such as pencil or ink, to create a more finished piece.</p>

                <p className='para'><b>Pastel Paint:</b> Pastel paint is made from a mixture of pigment, binder, and chalk, and it is often used to create soft, dreamy works. Unlike other painting mediums, pastel does not dry and remains somewhat fragile, so it is often protected with a fixative spray or a layer of glass. Pastel paintings can be created on paper, velour, or even a primed canvas.</p>

                <p className='para'><b>Gouache Paint:</b> Gouache paint is similar to watercolor paint in its use of water, but it is more opaque and has a thicker consistency. This makes it a popular choice for artists who want to create brightly colored, graphic pieces. Gouache paintings are often used in commercial and advertising design, but they can also be used to create beautiful fine art pieces.</p>
            </div>


        </section>
    )
}