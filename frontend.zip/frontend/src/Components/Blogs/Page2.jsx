import style from './Blog.module.css'

export default function Page2() {
    return (
        <section className={style.section}>
            <div className={style.page3}>
                <h5>THE ART OF FRAMING: TIPS FOR DISPLAYING AND PROTECTING YOUR ARTWORK</h5>
                <p class="pg1"><i>March 28, 2023</i></p>
                <p class="pg1"> In blog 0 comment</p>
            </div><br />
            <div className='container'>
                <p class="para">The right frame can enhance the beauty of your artwork and help protect it from damage caused by dust, moisture, and sunlight. Choosing the right frame for your art can be a challenge, but by following these tips, you can create a display that showcases your art to its fullest potential while also keeping it safe.</p>

                <p class="para"><b>Choose a frame that complements your artwork</b> <br />
                    When selecting a frame for your artwork, choose one that complements the style and colors of your piece. A frame that's too ornate or heavy can overpower a delicate painting, while a frame that's too plain can make a bold piece of art look boring. Look for a frame that enhances the colors and texture of your artwork and draws attention to its best features</p>

                <p class="para"><b>Select a mat that enhances the artwork</b><br />The mat serves as a buffer between the artwork and the frame, providing space for the artwork to "breathe" and preventing it from touching the glass. It also enhances the overall appearance of the artwork. Select a mat that is at least two inches wide on all sides to give your artwork a professional and polished look. Choose a color that complements the artwork, but avoid using a mat that is the same color as the artwork.</p>

                <p class="para"><b>Use archival materials</b><br />When it comes to framing artwork, it's important to use high-quality, archival materials that will protect your artwork from damage caused by light, dust, and moisture. Acid-free mat board, UV-filtering glass, and acid-free backing are all examples of archival materials that will help protect your artwork from damage over time.</p>
            </div>


        </section>
    )
}