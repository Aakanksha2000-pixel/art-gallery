import React, { useRef, useState } from 'react'
import { useDispatch } from 'react-redux'
import { registerHandler } from '../../Store/auth-reducer'
import style from './style.module.css'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

const Register = () => {
    const name = useRef()
    const email = useRef()
    const address = useRef()
    const phone = useRef()
    const password = useRef()
    const cpassword = useRef()
    const answer = useRef()
    const [gender, setGender] = useState()
    const dispatch = useDispatch()
    const navigate = useNavigate()

    const submitHandler = async (e) => {
        e.preventDefault()
        if (password.current.value === cpassword.current.value) {
            const response = await dispatch(registerHandler({ name: name.current.value, email: email.current.value, address: address.current.value, phone: phone.current.value, password: password.current.value, gender, answer: answer.current.value }))
            if(response.success){
                toast.success(`Registration Successfull. Please Login`)
                navigate('/login')
            }
            else{
                toast.error(response.err)
                navigate('/register')
            }
        }
        else{
            toast.error(`Password must be same`)
        }
    }
    return (<>
        <section className={`${style.box} p-5`}>
            <h1 className='logo mb-4 text-center text-light'>Register</h1>
            <div className='row justify-content-center'>
                <div className='col-lg-6 col-md-6 col-sm-12'>
                    <div className='p-4 bg-light shadow-sm'>
                        <div className={style.content}>
                            <form action="#" onSubmit={submitHandler}>
                                <div className={style.userDetails}>
                                    <div className='d-flex justify-content-between'>
                                        <div className="input-box d-flex flex-column me-1 w-100">
                                            <span className="details">Full Name</span>
                                            <input className='form-control' ref={name} type="text" placeholder="Full Name" required />
                                        </div>
                                        <div className="input-box d-flex flex-column w-100">
                                            <span className="details">Email</span>
                                            <input className='form-control' ref={email} type="text" placeholder="Email" required />
                                        </div>
                                    </div>
                                    <div className="input-box d-flex flex-column my-3">
                                        <span className="details">Address</span>
                                        <input className='form-control' ref={address} type='text' placeholder="Address" required />
                                    </div>
                                    <div className="input-box d-flex flex-column my-3">
                                        <span className="details">Phone Number</span>
                                        <input className='form-control' ref={phone} type="text" placeholder="Number" required />
                                    </div>
                                    <div className='d-flex justify-content-between'>
                                        <div className="input-box d-flex flex-column me-1 w-100">
                                            <span className="details">Password</span>
                                            <input className='form-control' ref={password} type="password" placeholder="Password" required />
                                        </div>
                                        <div className="input-box d-flex flex-column w-100 mx-1">
                                            <span className="details">Confirm Password</span>
                                            <input className='form-control' ref={cpassword} type="password" placeholder="Confirm Password" required />
                                        </div>
                                    </div>
                                </div>
                                <div className="gender-details d-flex flex-column my-3">
                                    <span className="gender-title">Gender</span>
                                    <div className='d-flex'>
                                        <div className='mx-2 my-1'><input type="radio" onClick={e => setGender(e.target.value)} name="gender" id="dot-1" value='Male' required /> Male</div>
                                        <div className='mx-2 my-1'><input type="radio" onClick={e => setGender(e.target.value)} name="gender" id="dot-2" value='Female' required /> Female</div>
                                        <div className='mx-2 my-1'><input type="radio" onClick={e => setGender(e.target.value)} name="gender" id="dot-3" value='Prefer not to say' required /> Prefer not to say</div>
                                    </div>
                                </div>
                                <div className="input-box d-flex flex-column my-3">
                                        <span className="details">Your Birth Place?</span>
                                        <input className='form-control' ref={answer} type="text" placeholder="Your answer" required />
                                </div>
                                <div className='d-flex justify-content-center'>
                                    <input type="submit" defaultValue="Register" className="btn button my-2" />
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </>)
}
export default Register
