import React, { useRef } from 'react'
import style from './style.module.css'
import { useDispatch } from 'react-redux'
import { authActions, loginHandler } from '../../Store/auth-reducer'
import { useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

const Login = () => {
    const email = useRef()
    const password = useRef()
    const dispatch = useDispatch()
    const navigate = useNavigate()

    const submitHandler = async (e) => {
        e.preventDefault()
        const success = await dispatch(loginHandler({ email: email.current.value, password: password.current.value }))
        if (success) {
            toast.success(`Welcome to the Art Corner`)
            dispatch(authActions.userHandler())
            dispatch(authActions.setActive())
            navigate('/')
        }
        else {
            toast.error(`Authentication Failed...`)
        }
    }
    return (
        <section className={`${style.box} p-5`}>
            <h1 className='logo mb-4 text-center text-light' >Login</h1>
            <div className='row justify-content-center'>
                <div className='col-lg-6 col-md-6 col-sm-12'>
                    <div className='p-4 bg-light shadow-sm'>
                        <div className={style.content}>
                            <form action="#" onSubmit={submitHandler}>
                                <div className={style.userDetails}>
                                    <div className='d-flex justify-content-between mt-4'>
                                        <div className="input-box d-flex flex-column w-100">
                                            <span className="details">Email</span>
                                            <input className='form-control' type="text" placeholder="Email" ref={email} required />
                                        </div>
                                    </div>
                                    <div className='d-flex justify-content-between mt-4'>
                                        <div className="input-box d-flex flex-column w-100">
                                            <span className="details">Password</span>
                                            <input className='form-control' type="password" placeholder="Password" ref={password} required />
                                        </div>
                                    </div>
                                </div>
                                <div className='d-flex justify-content-center'>
                                    <input type="submit" defaultValue="Register" className="btn button my-4" />
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}

export default Login