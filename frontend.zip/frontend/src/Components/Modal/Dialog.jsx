import {useState} from 'react'
import './Dialog.css'

const Dialog = (props) => {
  const [name, setName] = useState(props.name)
	return (
		<div className='modal'>
			<div className="dialog">
				<h2>{props.title}</h2>
				<input value={name} className='form-control' onChange={(e => setName(e.target.value))} />
				<div className='d-flex justify-content-center'>
					<button className="btn btn-dark my-2 w-50" onClick={() => props.update(name)}>{props.btnTitle}</button>
				</div>
				<button onClick={props.setDialogFun} aria-label="close" className="x">❌</button>
			</div>
		</div>
	)
}

export default Dialog