import React from 'react'
import Footer from '../Footer/Footer'
import Navigation from '../Navigation/Navigation'

const NavFooterWrapper = (props) => {
    return (
        <>
            <Navigation />
            {props.children}
            <Footer />
        </>
    )
}

export default NavFooterWrapper