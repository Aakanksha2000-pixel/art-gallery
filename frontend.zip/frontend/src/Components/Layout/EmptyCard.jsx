import Title from './Title'
import { BsCartXFill } from 'react-icons/bs'
import './EmptyCard.css'
import { useNavigate } from 'react-router-dom'

export default function EmptyCard(props) {
    const navigate = useNavigate()
    const navigateHandler = () => {
        navigate('/collections')
    }
    return (
        <div className='container empty_card'>
            <BsCartXFill />
            <Title title={props.title} ></Title>
            <div className='d-flex justify-content-center' >
                <button className={`btn button mt-4 w-100`} onClick={navigateHandler}>RETURN TO SHOP</button>
            </div>
        </div>
    )
}