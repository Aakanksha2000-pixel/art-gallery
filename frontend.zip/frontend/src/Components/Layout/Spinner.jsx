import React, { useEffect, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify'

const Spinner = ({ path = '/login' }) => {
    const [count, setCount] = useState(3)
    const navigate = useNavigate()
    const location = useLocation()

    useEffect(() => {
        const Interval = setInterval(() => {
            setCount(prevcount => --prevcount)
        }, 1000)

        if(count === 0) {
            navigate(`${path}`, {
                state: location.pathname
            })
            toast.error("You're not logged in. Please login first")
        }

        return () => clearInterval(Interval)
    }, [count, path, navigate, location.pathname])

    return (
        <>
            <div className="d-flex align-items-center justify-content-center" style={{ height: '100vh' }}>
                <h3 style={{ fontSize: '11pt', margin: '0 .5rem' }}>redirecting to the login page in {count}s</h3>
                <div className="spinner-border text-info spinner-border-sm" role="status">
                    <span className="visually-hidden">Loading...</span>
                </div>
            </div>
        </>
    )
}

export default Spinner