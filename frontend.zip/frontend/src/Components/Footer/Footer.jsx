import { Link } from 'react-router-dom'
import style from './Footer.module.css'

export default function Footer() {
    return (
        <section>
            <div className={`container-fluid ${style.footer} py-5 px-5 mt-5`}>
                <div className='row'>
                    <div className='col-lg-6 col-md-6 col-sm-12'>
                        <h3 className='logo'>-Art Corner-</h3>
                        <p className={style.desc}>Art Corner is a leading Online Art Gallery based in India & open to the world for connecting art and art admirers. You can browse and buy artworks and paintings online in few defined steps. Art Corner is a platform for promoting quality artwork created by artists worldwide.</p>
                    </div>
                    <div className='col-lg-3 col-md-3 col-sm-12'>
                        <h3 className={style.heading}>Quick Links</h3>
                        <ul className={style.desc}>
                            <Link to='/'><li>Home</li></Link>
                            <Link to='/about'><li>About</li></Link>
                            <Link to='/contact'><li>Contact</li></Link>
                            <Link to='/blogs'><li>Blogs</li></Link>
                        </ul>
                    </div>
                    <div className='col-lg-3 col-md-3 col-sm-12'>
                        <h3 className={style.heading}>Paintings</h3>
                        <ul className={style.desc}>
                            <li>Abstract paintings</li>
                            <li>Figurative Paintings</li>
                            <li>Landscape Paintings</li>
                            <li>Nature Paintings | Scenery Paintings</li>
                            <li>Religious Paintings</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div className={style.copyright}>
                <p className='bg-primary p-2 mb-0'>Copyright ©️ 2023. All rights reserved.</p>
            </div>
        </section>
    )
}