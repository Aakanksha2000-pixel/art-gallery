import React from 'react'
import style from './Profile.module.css'

const Dashboard = ({name, email, address, phone, onClick}) => {
    return (
        <>
            <h3>Hello, <span>{name}!</span></h3>
            <div className={style.acc_details}>
            <h5>Account details:</h5>

                <table className='table table-bordered'>
                    <tbody className={style.tbody}>
                        <tr>
                            <td className="text-left"><strong>Name:</strong></td>
                            <td>{name}</td>
                        </tr>
                        <tr>
                            <td className="text-left"><strong>E-mail:</strong></td>
                            <td>{email}</td>
                        </tr>
                        <tr>
                            <td className="text-left"><strong>Phone:</strong></td>
                            <td>{phone}</td>
                        </tr>
                        <tr>
                            <td className="text-left"><strong>Address:</strong></td>
                            <td>{address}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </>
    )
}

export default Dashboard