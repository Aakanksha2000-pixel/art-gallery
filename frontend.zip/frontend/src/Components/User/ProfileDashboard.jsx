import React from 'react'
import { useDispatch } from 'react-redux'
import { Link, useNavigate } from 'react-router-dom'
import { authActions } from '../../Store/auth-reducer'
import style from './Profile.module.css'

const ProfileDashboard = () => {
    const dispatch = useDispatch()
    const navigate = useNavigate()

    const logoutHandler = () => {
        dispatch(authActions.logoutHandler())
        navigate('/login')
    }
    return (
        <>
            <table className='table table-bordered table-striped mt-5'>
                <tbody>
                    <tr><td className={`p-2 ${style.profile_link}`} ><Link to='/dashboard/user/profile'>Dashboard</Link></td></tr>
                    <tr><td className={`p-2 ${style.profile_link}`} ><Link to='/dashboard/user/orders'>Orders</Link></td></tr>
                    <tr><td className={`p-2 ${style.profile_link}`} onClick={logoutHandler}>Logout</td></tr>
                </tbody>
            </table>
        </>
    )
}

export default ProfileDashboard