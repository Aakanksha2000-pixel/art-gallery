import Title from '../Layout/Title'
import img2 from '../../assets/img/user.avif'
import style from './Profile.module.css'
import Dashboard from './Dashboard'
import { useState, useEffect } from 'react'
import { useSelector } from 'react-redux'
import ProfileDashboard from './ProfileDashboard'
import NavFooterWrapper from '../Layout/NavFooterWrapper'

export default function Profile() {
    const [user, setUser] = useState({})
    const auth = useSelector(state => state.auth)

    useEffect(() => {
        setUser(auth?.user)
    }, [auth?.user])

    return (
        <NavFooterWrapper>
            <div className={`${style.profile}`}>
                <div className={`${style.hero_image} container-fluid`}>
                    <Title title='My account' />
                </div>
                <div className='container mt-5'>
                    <div className={`row ${style.user_profile} align-items-start`}>
                        <div className='col-lg-4 d-flex justify-content-center'>
                            <div className='row'>
                                <div className='col-12 d-flex justify-content-center align-item-center'><img src={img2} alt='' /></div>
                                <div className='col-12'>
                                    <ProfileDashboard />
                                </div>
                            </div>
                        </div>
                        <div className={`col-lg-8 ${style.account}`}>
                            <Dashboard name={user.name} email={user.email} address={user.address} phone={user.phone} />
                        </div>
                    </div>
                </div>
            </div >
        </NavFooterWrapper>
    )
}