import React from "react";
import { useState, useReducer } from "react";

export const wishContext = React.createContext({
    modalIsOpen: false,
    liked: false,
    items: [],
    totalQuantity: 0,
    ToggleFunction: () => { },
    addItem: () => { },
    removeItem: () => { }
})

const initValue = {
    items: [],
    totalQuantity: 0
}

function wishlistReducer(state, action) {
    let totalQuantity = state.totalQuantity
    if (action.type === 'ADD') {
        const isExistsIndex = state.items.findIndex(item => item.id === action.item.id)
        let existingItem = state.items[isExistsIndex]

        let updatedArray
        if (!existingItem) {
            updatedArray = state.items.concat(action.item)
            totalQuantity += 1
        }
        else { updatedArray = [...state.items] }
        return {
            items: updatedArray,
            totalQuantity
        }
    }
    else if (action.type === 'REMOVE') {

        totalQuantity -= 1

        let updatedArray
        updatedArray = state.items.filter(item => item.id !== action.id)
        return {
            items: updatedArray,
            totalQuantity
        }
    }
}

export default function WishProvider(props) {
    const [isModalOpen, setisModalOpen] = useState(false)
    const [wishlist, dispatch] = useReducer(wishlistReducer, initValue)

    function setModalToggle() {
        setisModalOpen(!isModalOpen)
    }
    function addItemHandler(item) {
        dispatch({ type: 'ADD', item })
    }
    function removeItemHandler(id) {
        dispatch({ type: 'REMOVE', id })
    }
    const wish_value = {
        modalIsOpen: isModalOpen,
        items: wishlist.items,
        totalQuantity: wishlist.totalQuantity,
        ToggleFunction: setModalToggle,
        addItem: addItemHandler,
        removeItem: removeItemHandler
    }
    return (
        <wishContext.Provider value={wish_value}>{props.children}</wishContext.Provider>
    )
}