import { useEffect } from 'react';
import { Routes, Route } from 'react-router-dom'
import Collections from "./Components/Navigation/Collections";
import Profile from './Components/User/Profile'
import Categories from './Components/UI/Categories'
import Home from "./Components/Home/Home";
import SellPaintings from './Components/SellPaintings/SellPaintings';
import About from './Components/UI/About';
import Contact from './Components/UI/Contact'
import Blog from './Components/Blogs/Blog'
import Page1 from './Components/Blogs/Page1'
import Page2 from './Components/Blogs/Page2'
import Page3 from './Components/Blogs/Page3'
import Page4 from './Components/Blogs/Page4'
import Page6 from './Components/Blogs/Page6'
import Shipping from './Components/Shipping/Shipping';
import Login from './Components/Auth/Login';
import Painting from './Components/Navigation/Painting';
import Register from './Components/Auth/Register';
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import PrivateRoutes from './Routes/PrivateRoutes';
import AdminRoutes from './Routes/AdminRoutes';
import Users from './Components/Admin/Users';
import Products from './Components/Admin/Products';
import ProductForm from './Components/Admin/ProductForm';
import Category from './Components/Admin/Category';
import Orders from './Components/User/Orders';
import Admin from './Components/Admin/Admin';

function App() {

  useEffect(() => {
    fetch('./Context/dummy.json').then((response) => response.json()).then(res => console.log(res))
  }, [])

  return (
    <>
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/register' element={<Register />} />
        <Route path='/login' element={<Login />} />
        <Route path='/collections' element={<Categories />} />
        <Route path={`/:id`} element={<Collections />} />
        <Route path={`/collections/:id`} element={<Painting />} />
        {/* user routes */}
        <Route path='/dashboard/user' element={<PrivateRoutes />}>
          <Route path='profile' element={<Profile />} />
          <Route path='sell-paintings' element={<SellPaintings />} />
          <Route path='shipping' element={<Shipping />} />
          <Route path='orders' element={<Orders />} />
        </Route>
        {/* Admin routes */}
        <Route path='/authorized/admin' element={<AdminRoutes />}>
          <Route path='profile' element={<Admin />}></Route>
          <Route path='create-product' element={<ProductForm />}></Route>
          <Route path='products' element={<Products />}></Route>
          <Route path='category' element={<Category />}>
            <Route path=':id' element={<></>}></Route>
          </Route>
          <Route path='users' element={<Users />}></Route>
        </Route>
        <Route path='/about' element={<About />} />
        <Route path='/contact' element={<Contact />} />
        <Route path='/blogs' >
          <Route index element={<Blog />} />
          <Route path='/blogs/:id' element={<Page1 />} />
          <Route path='/blogs/:id' element={<Page2 />} />
          <Route path='/blogs/:id' element={<Page3 />} />
          <Route path='/blogs/:id' element={<Page4 />} />
          <Route path='/blogs/:id' element={<Page6 />} />
        </Route>
        <Route path='/*' element={<h4>Page Not Found!</h4>} />
      </Routes>
      <ToastContainer />
    </>
  )
}

export default App;