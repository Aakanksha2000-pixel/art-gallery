import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom'
import './index.css';
import App from './App';
import CartProvider from './Context/cart-context';
import WishProvider from './Context/wishlist-context';
import DescriptionProvider from './Context/description-context';
import FilterProvider from './Context/filter-context';
import Store from './Store';
import { Provider } from 'react-redux/es/exports';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  // <React.StrictMode>
  <Provider store={Store}>
    <CartProvider>
      <WishProvider>
        <DescriptionProvider>
          <FilterProvider>
            <BrowserRouter><App /></BrowserRouter>
          </FilterProvider>
        </DescriptionProvider>
      </WishProvider>
    </CartProvider>
  </Provider>
  // </React.StrictMode>
)
