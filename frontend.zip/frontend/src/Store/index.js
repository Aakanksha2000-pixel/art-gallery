import { configureStore } from '@reduxjs/toolkit'
import authSlice from './auth-reducer'
import categorySlice from './category-reducer'
import productSlice from './product-reducer'
import userSlice from './user-reducer'

const Store = configureStore({
    reducer: {
        auth: authSlice.reducer,
        product: productSlice.reducer,
        category: categorySlice.reducer,
        user: userSlice.reducer
    }
})

export default Store