import { createSlice } from '@reduxjs/toolkit'

const userSlice = createSlice({
	name: 'user',
	initialState: { loader: false },
	reducers: {
		setLoader(state){
			state.loader = !state.loader
		}
	}
})

export const getUsers = ()=>{
	return async ()=>{
		const response = await fetch('http://localhost:5000/api/v1/auth')
		const res = await response.json()
		return res.success ? res.users : false
	}
}

export const userActions = userSlice.actions
export default userSlice  