import { createSlice } from "@reduxjs/toolkit";

const productSlice = createSlice({
    name: 'product',
    initialState: { loader: false },
    reducers: {
        setLoader(state) {
            state.loader = !state.loader
        }
    }
})

export const getProducts = (token) => {
    return async () => {
        const response = await fetch('http://localhost:5000/api/v1/product',{
            headers: {
                'Authorization': token
            }
        })
        const res = await response.json()
        return res.success ? res.products : false
    }
}

export const productActions = productSlice.actions
export default productSlice