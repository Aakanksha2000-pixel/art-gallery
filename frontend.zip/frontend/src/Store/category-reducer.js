import { createSlice } from "@reduxjs/toolkit";

const categorySlice = createSlice({
    name: 'category',
    initialState: { loader: false },
    reducers: {
        setLoader(state) {
            state.loader = !state.loader
        }
    }
})

export const getCategories = (token) => {
    return async () => {
        const response = await fetch('http://localhost:5000/api/v1/category', {
            headers: {
                'Authorization': token
            }
        })
        const res = await response.json()
        return res.success ? res.categories : false
    }
}

export const createCategory = (token, data) => {
    return async () => {
        const response = await fetch('http://localhost:5000/api/v1/category', {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                'Authorization': token
            },
            body: JSON.stringify(data)
        })
        const res = await response.json()
        return res.success
    }
}

export const updateCategory = (token, id, data) => {
    return async () => {
        console.log(token, id, data)
        const response = await fetch(`http://localhost:5000/api/v1/category/${id}`, {
            method: 'PATCH',
            headers: {
                'content-type': 'application/json',
                'Authorization': token
            },
            body: JSON.stringify({name: data})
        })
        const res = await response.json()
        return res
    }
}

export const deleteCategory = (token, id) => {
    return async () => {
        const response = await fetch(`http://localhost:5000/api/v1/category/${id}`, {
            method: 'DELETE',
            headers: {
                'Authorization': token
            }
        })
        const res = await response.json()
        return res
    }
}

export const categoryActions = categorySlice.actions
export default categorySlice