import { createSlice } from '@reduxjs/toolkit'

const authSlice = createSlice({
    name: 'auth',
    initialState: { active: false, user: JSON.parse(localStorage.getItem('user')), token: localStorage.getItem('token') },
    reducers: {
        userHandler(state) {
            state.token = localStorage.getItem('token')
            state.user = JSON.parse(localStorage.getItem('user'))
        },
        setActive(state) {
            state.active = !state.active
        },
        logoutHandler(state) {
            state.active = false
            state.user = null
            state.token =  null
            localStorage.removeItem('token')
            localStorage.removeItem('user')
        }
    }
})

export const loginHandler = (data) => {
    return async () => {
        const res = await fetch('http://localhost:5000/api/v1/auth/login', {
            method: 'POST',
            headers: {
                'content-type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        const result = await res.json()
        if (result.success) {
            localStorage.setItem('token', result.response.token)
            localStorage.setItem('user', JSON.stringify(result.response.user))
        }
        return result.success
    }
}

export const registerHandler = (data) => {
    return async () => {
        console.log(data)
        const res = await fetch('http://localhost:5000/api/v1/auth/register', {
            method: 'POST',
            headers: {
                'content-type': 'application/json'
            },
            body: JSON.stringify(data)
        })
        const response = await res.json()
        console.log(response)
        return response
    }
}

export const authActions = authSlice.actions
export default authSlice