import Carousel from "./Carousel"
import Slide from "../Slider/Slider"
import Posts from "../Posts/Posts"
import Poster from './Poster'
import Supports from "../Posts/Supports"
import Gallery from "./Gallery"

export default function Home() {
    return (
        <>
            <Carousel />
            <Gallery />
            <Slide title='- Our Featured -' />
            <Supports />
            <Slide title='- Most Popular -' />
            <Poster />
            <Slide title='- Latest -' />
            <Posts />
        </>
    )
}