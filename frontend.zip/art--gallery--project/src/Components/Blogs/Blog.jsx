import ghat from '../../assets/img/blog1 (1).jpeg';
import frame from '../../assets/img/blog1 (7).jpeg';
import paint from '../../assets/img/blog1 (3).jpeg';
import beginner from '../../assets/img/blog1 (4).jpeg';
import taj from '../../assets/img/blog1 (6).jpeg';
import style from './Blog.module.css'
import { Link } from 'react-router-dom';

export default function Blog() {
    return (
        <section className={style.section}>
            <div className={style.Blog}>
                <h1 className='heading'>Blog</h1>
                <p>awesome place to make oneself <br /> productive and entertained through daily updates.</p>
            </div>
            <div className="container mt-5">
                <div className="row">
                    <div className="col-sm m-5">
                        <Link to="/blogs/1">
                            <div className={style.cards}>
                                <img src={ghat} alt="..."
                                    className="card-img-top"
                                />
                                <div className="card-body flex-column px-2">
                                    <h4 className={style.card_title}>A tale associated with the ghats of India.[Banaras]</h4>
                                    <p className={style.card_text}><i>on April 20, 2023</i></p>
                                </div>
                            </div>
                        </Link>
                    </div>
                    <div className="col-sm m-5">
                        <Link to="/blogs/2">
                            <div className={style.cards}>
                                <img src={frame} alt="..."
                                    className="card-img-top"
                                />
                                <div className="card-body flex-column px-2">
                                    <h4 className={style.card_title}>How to Create a Gallery Wall: Tips and Tricks...</h4>
                                    <span className={style.card_text}><i>on March 28, 2023</i></span>
                                </div>
                            </div>
                        </ Link>
                    </div>
                    <div className="col-sm m-5">
                        <Link to="/blogs/3">
                            <div className={style.cards}>
                                <img src={paint} alt="..."
                                    className="card-img-top"
                                />
                                <div className="card-body flex-column px-2">
                                    <h4 className={style.card_title}>An Introduction to Different Painting Mediums...</h4>
                                    <span className={style.card_text}><i>on February 10, 2023</i></span>
                                </div>
                            </div>
                        </Link>
                    </div>
                </div>

                <div className="row">
                    <div className="col-sm m-5">
                        <Link to="/blogs/4">
                            <div className={style.cards}>
                                <img src={beginner} alt="..."
                                    className="card-img-top"
                                />
                                <div className="card-body flex-column px-2">
                                    <h4 className={style.card_title}>A tale associated with the ghats of India.[Banaras]</h4>
                                    <span className={style.card_text}><i>on April 20, 2023</i></span>
                                </div>
                            </div>
                        </Link>
                    </div>
                    <div className="col-sm m-5">
                        <Link to="/blogs/6">
                            <div className={style.cards}>
                                <img src={taj} alt="..."
                                    className="card-img-top"
                                />
                                <div className="card-body flex-column px-2">
                                    <h4 className={style.card_title}>An Introduction to Different Painting Mediums...</h4>
                                    <span className={style.card_text}><i>on February 10, 2023</i></span>
                                </div>
                            </div>
                        </Link>
                    </div>
                </div>
            </div>
        </section>
    )
}