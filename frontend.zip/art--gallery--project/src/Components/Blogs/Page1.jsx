import React from "react";
import style from './Blog.module.css'

export default function Page1() {
    return (
        <section className={style.section}>
            <div className={style.page2}>
                <h5>A TALE ASSOCIATED WITH THE GHATS OF INDIA.</h5>
                <p class="pg1">April 20, 2023</p>
                <p class="pg1"> In blog 0 comment</p>
            </div><br />
            <div className="container">
                <p class="para">Banaras, also known as Varanasi, is a city in northern India that is famous for its ghats - a series of steps leading down to the banks of the Ganges river. The ghats of Banaras have long been a popular subject for artists, and there are many paintings that depict these iconic locations.</p>

                <p class="para">Banaras ghat paintings often feature vibrant colors, intricate details, and a sense of bustling activity. They may show people bathing in the river, performing religious rituals, or going about their daily lives. The paintings may also depict the architecture of the ghats themselves, with their ornate arches, temples, and pavilions.</p>

                <p class="para">One notable aspect of Banaras ghat paintings is the way they capture the interplay between light and water. Many of the paintings show the reflection of the ghats in the river, creating a shimmering, dreamlike effect. Others use light and shadow to create a sense of depth and texture.</p>

                <p class="para">Banaras ghat paintings can be found in a variety of styles, from traditional Indian miniature painting to contemporary abstract works. They are a testament to the enduring beauty and cultural significance of this ancient city, and serve as a reminder of the rich artistic heritage of India.</p>
            </div>
        </section>
    )
}