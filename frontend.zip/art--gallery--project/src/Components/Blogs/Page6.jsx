import style from './Blog.module.css'

export default function Page6() {
    return (
        <section className={style.section}>
            <div className={style.page3}>
                <h5>MAA DURGA-THE WARRIOR GODDESS!</h5>
                <p class="pg1"><i>September 17, 2022</i></p>
                <p class="pg1"> In blog 0 comment</p>
            </div><br />
            <div className="container">
                <p class="para"><b> Summary: </b>Indian art history dates back to around 2500 BC. Different factors have inspired artists in India to paint. Indian paintings were often inspired by spirituality and sensuality, making it stand out in terms of content and aesthetics, an aspect that is appreciated even today.</p>

                <p className="para">The history of Indian art is almost as old as its civilisation. Indian art is considered to have originated during the peak of the Indus Valley Civilization, somewhere around 2500 BC. Indian paintings during the time were often inspired by spirituality and sensuality, making it stand out in terms of content and aesthetics, an aspect that is appreciated even today.</p>

                <p className="para">However, with the changing times, wars, invasions and with the merger of different cultures and civilisations, art in India has changed drastically.</p>

                <p className="para">There are four different periods/events that can help you understand  -</p>

                <h4 className="para"><b>The evolution of Indian Paintings:</b></h4>

                <p className='para'><b> Ancient civilisation: </b> <br />
                    This period can be dated between 3200 – 1200. This is the time when the Indus Valley civilisation was at its peak. It has been proven that the civilisation was pretty advanced in terms of Science and culture, something that is reflected in the painting curated during the time.</p>

                <p className='para'><b>Islamic Influence: </b> <br />
                    With the invasion of the Mughals and other Islamic rulers, came in the beautiful influence of Islamic culture. The Mughals who ruled India from the 16th century to the late 19 century especially left a lasting impression on India’s culture, clothing, food andIndian Paintings. The Islamic influence was not only restricted to paintings and sculptures. Trace of their influence was seen in the architecture built during the period.</p>

                <p className='para'><b>Colonisation: </b><br />
                    The arrival of Vasco da Gama was a defining moment when it comes to the western influence on Indian heritage. This period was highly influenced by western, mostly European influence. Be it the French, Portuguese, Denmark or England, the influence of the western world is something that can be experienced even today.</p>

                <p className='para'><b>Post colonisation: </b><br />
                    As modernization crept in, India had already fought and won its independence. This modern India had seen it all, be it the raging world wars, oppression, invasion, struggle, independence, evolution of cultures, etc. All these aspects have impacted the way we paint even today. <br /> <br />
                    Art has not only evolved in its content or in the way it is made, art has also evolved in the way it is being showcased, appreciated, or sold. Gone are the days when you had to travel or queue up to have glimpse Online galleries like Gallerist.in have made purchasing art a convenient and hassle-free experience.</p>
            </div>
        </section>
    )
}