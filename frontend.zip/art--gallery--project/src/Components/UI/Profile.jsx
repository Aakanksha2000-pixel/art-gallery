import Title from '../Layout/Title'
import img2 from '../../assets/img/user.avif'
import style from './Profile.module.css'

export default function Profile() {
    return (
        <div class={`${style.profile}`}>
            <div class={`${style.hero_image} container-fluid`}>
                <Title title='My account' />
            </div>
            <div className='container mt-5'>
                <div className={`row ${style.user_profile}`}>
                    <div className='col-lg-4 d-flex justify-content-center'>
                        <img src={img2} alt='' />
                    </div>
                    <div className={`col-lg-8 ${style.account}`}>
                        <h3>Hello <span>Aakanksha Mahajan</span></h3>
                        <div className={style.acc_details}>
                            <h5>Account details:</h5>

                            <table className='table table-bordered'>
                                <tbody className={style.tbody}>
                                    <tr>
                                        <td class="text-left"><strong>Name:</strong></td>
                                        <td>Aakanksha Mahajan</td>
                                    </tr>
                                    <tr>
                                        <td class="text-left"><strong>E-mail:</strong></td>
                                        <td>aakansha71089@gmail.com</td>
                                    </tr>
                                    <tr>
                                        <td class="text-left"><strong>Address:</strong></td>
                                        <td>Some street, 1245 Some city</td>
                                    </tr>
                                    <tr>
                                        <td class="text-left"><strong>Address 2:</strong></td>
                                        <td>Some street, 1245 Some city</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}