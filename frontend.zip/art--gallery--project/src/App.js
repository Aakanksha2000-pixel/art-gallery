import { Routes, Route } from 'react-router-dom'
import Navigation from "./Components/Navigation/Navigation";
import Collections from "./Components/Navigation/Collections";
import Profile from './Components/UI/Profile'
import Categories from './Components/UI/Categories'
import Home from "./Components/Home/Home";
import Footer from './Components/Footer/Footer'
import SellPaintings from './Components/SellPaintings/SellPaintings';
import About from './Components/UI/About';
import Contact from './Components/UI/Contact'
import Blog from './Components/Blogs/Blog'
import Page1 from './Components/Blogs/Page1'
import Page2 from './Components/Blogs/Page2'
import Page3 from './Components/Blogs/Page3'
import Page4 from './Components/Blogs/Page4'
import Page6 from './Components/Blogs/Page6'

function App() {

  return (
    <>
      <Navigation />
      <Routes>
        <Route path='/' element={<Home />} />
        <Route path='/collections' element={<Categories />} />
        <Route path={`/:id`} element={<Collections />} />
        <Route path='/sell-paintings' element={<SellPaintings />} />
        <Route path='/profile' element={<Profile />} />
        <Route path='/about' element={<About />} />
        <Route path='/contact' element={<Contact />} />
        <Route path='/blogs' >
          <Route index element={<Blog />} />
          <Route path='/blogs/:id' element={<Page1 />} />
          <Route path='/blogs/:id' element={<Page2 />} />
          <Route path='/blogs/:id' element={<Page3 />} />
          <Route path='/blogs/:id' element={<Page4 />} />
          <Route path='/blogs/:id' element={<Page6 />} />
        </Route>
        <Route path='/*' element={<Home />} />
      </Routes>
      <Footer />
    </>
  )
}

export default App;