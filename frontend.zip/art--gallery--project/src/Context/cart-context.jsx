import React from "react";
import { useState, useReducer } from "react";

export const cartContext = React.createContext({
    modalIsOpen: false,
    items: [],
    subTotal: 0,
    totalQuantity: 0,
    ToggleFunction: () => { },
    addItem: () => { },
    removeItem: () => { },
    success: false
})

const initValue = {
    item: [],
    subtotal: 0,
    totalQuantity: 0,
    success: false
}

function cartReducer(state, action) {
    let totalQuantity = state.totalQuantity
    if (action.type === 'ADD') {
        const isExistsIndex = state.item.findIndex(item => item.id === action.payload.id)
        let existingItem = state.item[isExistsIndex]

        let updatedItems;
        let subtotal = state.subtotal + action.payload.quantity * action.payload.price
        totalQuantity += 1
        console.log(totalQuantity)
        if (existingItem) {
            const updatedItem = {
                ...existingItem,
                quantity: existingItem.quantity + action.payload.quantity,
                totalPrice: existingItem.totalPrice + action.payload.price
            }
            updatedItems = [...state.item]
            updatedItems[isExistsIndex] = updatedItem
        }
        else {
            updatedItems = state.item.concat(action.payload)
        }
        return {
            item: updatedItems,
            subtotal: subtotal,
            totalQuantity,
            success: true
        }
    }
    if (action.type === 'REMOVE') {
        const isExistsIndex = state.item.findIndex(item => item.id === action.id)
        let existingItem = state.item[isExistsIndex]

        let updatedItems;
        let subtotal = state.subtotal - existingItem.price
        totalQuantity -= 1
        if (existingItem.quantity !== 1) {
            const updatedItem = {
                ...existingItem,
                quantity: existingItem.quantity - 1,
                totalPrice: existingItem.totalPrice - existingItem.price
            }
            updatedItems = [...state.item]
            updatedItems[isExistsIndex] = updatedItem
        }
        else {
            updatedItems = state.item.filter(item => item.id !== action.id)
        }
        return {
            item: updatedItems,
            subtotal: subtotal,
            totalQuantity,
            success: true
        }
    }
}

export default function CartProvider(props) {
    const [isModalOpen, setisModalOpen] = useState(false)
    const [cart, dispatch] = useReducer(cartReducer, initValue)
    function setModalToggle() {
        setisModalOpen(!isModalOpen)
    }
    function addItemHandler(item) {
        dispatch({ type: 'ADD', payload: item })
    }
    function removeItemHandler(id) {
        dispatch({ type: 'REMOVE', id })
    }
    const cart_value = {
        modalIsOpen: isModalOpen,
        items: cart.item,
        subTotal: cart.subtotal,
        totalQuantity: cart.totalQuantity,
        ToggleFunction: setModalToggle,
        addItem: addItemHandler,
        removeItem: removeItemHandler,
        success: cart.success
    }
    return (
        <cartContext.Provider value={cart_value}>{props.children}</cartContext.Provider>
    )
}