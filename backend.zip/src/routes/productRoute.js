const express = require('express')
const { createProduct, getAProduct, getAllProducts, updateProduct,
    deleteProduct, wishList, rating, uploadImgaes, deleteImgaes } = require('../controller/productCtrl')
const { isAdmin, authMiddleware } = require('../middlewares/authMiddleware');
const { uploadPhoto, blogImgResize } = require('../middlewares/uploadImages');
const router = express.Router()

router.put("/rating", authMiddleware, rating);
router.get('/:id', getAProduct)
router.get('/', getAllProducts)

router.post('/', authMiddleware, isAdmin, createProduct)
router.put('/upload/', authMiddleware, isAdmin, uploadPhoto.array('images', 10), blogImgResize, uploadImgaes)
router.put("/wishlist", authMiddleware, wishList)

router.put('/:id', authMiddleware, isAdmin, updateProduct)

router.delete('/:id', authMiddleware, isAdmin, deleteProduct)
router.delete('/deleteImages/:id', authMiddleware, isAdmin, deleteImgaes)

module.exports = router