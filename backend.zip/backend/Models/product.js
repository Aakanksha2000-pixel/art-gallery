const mongoose = require('mongoose')

const Schema = mongoose.Schema({
    id: {type: Number, required: true, unique: true},
    title: {
        type: String,
        required: true,
        trim: true
    },
    description:{
        type: String,
        required: true,
        trim: true
    },
    price: {
        type: Number,
        required: true,
        trim: true
    },
    rating: {
        type: Number,
        required: true,
        trim: true
    },
    stock: {
        type: Number,
        required: true,
        trim: true
    },
    category: {
        type: String,
        required: true,
        trim: true
    },
    thumbnail: {
        type: {
            data: Buffer,
            contentType: String
        } ,
        required: true,
        trim: true
    },
})
const Paintings = mongoose.model('paintings', Schema)
module.exports = Paintings