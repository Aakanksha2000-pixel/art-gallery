const JWT = require('jsonwebtoken')
const Users = require('../Models/user')
require('dotenv').config()

const requireSignin = async (req, res, next) => {
    try {
        const decode = JWT.verify(req.headers.authorization, process.env.SECRET_KEY)
        req.user = decode
        next()
    } catch (err) {
        res.status(404).json({ success: false, message: 'Error...', err: err.message })
    }
}

const isAdmin = async (req, res, next) => {
    try {
        const user = await Users.findById({ _id: req.user._id })
        if (user.role !== 1) res.status(400).send({ success: false, message: 'Unauthorized Access' })
        else next()
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}

module.exports = { requireSignin, isAdmin }