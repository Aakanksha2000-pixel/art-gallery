const mongoose = require('mongoose')
require('dotenv').config()

mongoose.connect(process.env.MONGO_CONNECT).then(() => console.log('Connected to the database')).catch(() => console.log('Connected to the database'))