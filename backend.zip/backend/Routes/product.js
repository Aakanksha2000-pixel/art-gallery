const express = require('express')
const { getProducts, createProduct, updateProduct, deleteProduct, getProduct, deleteAll } = require('../Controllers/product')
const { requireSignin, isAdmin } = require('../middlewares/authMiddleware')
const productRouter = express.Router()

productRouter.get('/', getProducts)
productRouter.get('/:id', getProduct)
productRouter.post('/', requireSignin, isAdmin, createProduct)
productRouter.patch('/:id', requireSignin, isAdmin, updateProduct)
productRouter.delete('/:id', requireSignin, isAdmin, deleteProduct)
productRouter.delete('/', deleteAll)

module.exports = productRouter