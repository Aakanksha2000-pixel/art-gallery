const express = require('express')
const { getUser, login, register, getUsers } = require('../Controllers/user')
const { requireSignin, isAdmin } = require('../middlewares/authMiddleware')
const userRouter = express.Router()

userRouter.get('/', getUsers)
userRouter.post('/login', login)
userRouter.post('/register', register)
userRouter.get('/admin-auth', requireSignin, isAdmin, (req, res) => {
    res.send({ success: true, msg: 'Valid Admin!' })
})
userRouter.get('/user-auth', requireSignin, (req, res) => {
    res.send({ success: true, msg: 'Valid User!' })
})
userRouter.get('/:id', getUser)


module.exports = userRouter