const express = require('express')
const { getCategories, getCategory, createCategory, updateCategory, deleteCategory } = require('../Controllers/category')
const { requireSignin, isAdmin } = require('../middlewares/authMiddleware')
const categoryRouter = express.Router()

categoryRouter.get('/', requireSignin, isAdmin, getCategories)
categoryRouter.get('/:id', requireSignin, isAdmin, getCategory)
categoryRouter.post('/', requireSignin, isAdmin, createCategory)
categoryRouter.patch('/:id', requireSignin, isAdmin, updateCategory)
categoryRouter.delete('/:id', requireSignin, isAdmin, deleteCategory)

module.exports = categoryRouter