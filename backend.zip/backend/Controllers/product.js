const Paintings = require("../Models/product")
const fs = require('fs')
const multer = require('multer')

const getProducts = async (req, res) => {
    try {
        const products = await Paintings.find({})
        res.status(200).send({ success: true, products })
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}

const getProduct = async (req, res) => {
    try {
        const product = await Paintings.findById({ _id: req.body.id })
        res.status(200).send({ success: true, product })
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}

const fileStorageEngine = multer.diskStorage({
    destination: (req, file, cb)=>{
        cb(null, "./images")
    },
    filename: (req, file, cb)=>{
        cb(null, Date.now() + '...' + file.originalname)
    }
})

const upload = multer({storage: fileStorageEngine}).single('thumbnail')

const createProduct = async (req, res) => {
    try {
        // fs.readFile('data.json', 'utf-8', (err, products) => {
        //     if (err) console.log(err)
        //     const Products = JSON.parse(products)

        //     Products.forEach(async product => {
        //         const newProduct = await new Paintings({ id: product.id, title: product.title, description: product.description, price: product.price, rating: product.rating, stock: product.stock, category: product.category, thumbnail: product.thumbnail })
        //         await newProduct.save()
        //     })
        // })
        // res.status(200).send({ success: true, msg: 'products created...' })

        const { title, description, price, rating, stock, category, thumbnail } = req.body
        upload(req, res, async (err) => {
            if(err) res.send(err)
                else {
                    const newProduct = await new Paintings({ title, description, price, rating, stock, category, thumbnail: {
                            data: thumbnail,
                            contentType: 'image/png'
                    } })
                    const product = await newProduct.save()
                    res.status(200).send({ success: true, product })
                }
        })
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}
const updateProduct = async (req, res) => {
    try {
        const { title, description, price, rating, stock, category, thumbnail } = req.body
        const product = await Paintings.findByIdAndUpdate({ _id: req.body.id }, { title, description, price, rating, stock, category, thumbnail }, { new: true })
        res.status(200).send({ success: true, product })
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}

const deleteProduct = async (req, res) => {
    try {
        await Paintings.findByIdAndDelete({ _id: req.body.id })
        res.status(200).send({ success: true, message: 'Product deleted successfully...' })
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}

const deleteAll = async (req, res) => {
    try {
        await Paintings.deleteMany({})
        res.status(200).send({ success: true, message: 'Products deleted successfully...' })
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}

module.exports = { getProduct, getProducts, createProduct, updateProduct, deleteProduct, deleteAll }