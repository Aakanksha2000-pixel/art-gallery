const Categories = require("../Models/category")

const getCategories = async (req, res) => {
    try {
        const categories = await Categories.find({})
        res.status(200).send({ success: true, categories })
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}

const getCategory = async (req, res) => {
    try {
        const category = await Categories.findById({ _id: req.body.id })
        res.status(200).send({ success: true, category })
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}

const createCategory = async (req, res) => {
    try {
        const { name } = req.body
        const isCategoryExists = await Categories.findOne({ name })
        if (isCategoryExists) {
            res.status(404).send({ success: false, message: 'Error', err: 'category already exists' })
        }
        else {
            const newCategory = await new Categories({ name })
            const category = await newCategory.save()
            res.status(200).send({ success: true, category })
        }
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}
const updateCategory = async (req, res) => {
    try {
        const { name } = req.body
        const response = await Categories.findByIdAndUpdate({ _id: req.params.id }, { name }, { new: true })
        res.status(201).send({
            success: true,
            msg: 'category updated successfully',
            response
        })
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}
const deleteCategory = async (req, res) => {
    try {
        await Categories.findByIdAndDelete({ _id: req.params.id })
        res.status(201).send({
            success: true,
            message: 'Category deleted successfully'
        })
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}

module.exports = { getCategories, getCategory, createCategory, updateCategory, deleteCategory }