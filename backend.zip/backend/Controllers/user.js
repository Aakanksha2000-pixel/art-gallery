const { hashPassword, comparePassword } = require("../helpers/authHelper")
const Users = require("../Models/user")
const jwt = require('jsonwebtoken')

const getUsers = async (req, res) => {
    try {
        const users = await Users.find({})
        res.status(200).send({ success: true, users })
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}

const getUser = async (req, res) => {
    try {
        const user = await Users.findById({ _id: req.params.id })
        res.status(200).send({ success: true, user })
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}

const login = async (req, res) => {
    try {
        const { email, password } = req.body
        const isUserExists = await Users.findOne({ email })
        if (isUserExists) {
            const isMatched = await comparePassword(password, isUserExists.password)
            if (isMatched) {
                const token = jwt.sign({ _id: isUserExists._id }, process.env.SECRET_KEY, {
                    expiresIn: '7d'
                })
                res.send({ success: true, response: { user: {
                    name: isUserExists.name,
                    email: isUserExists.email,
                    phone: isUserExists.phone,
                    address: isUserExists.address,
                    answer: isUserExists.answer,
                    role: isUserExists.role
                } , token } })
            }
        }
    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}

const register = async (req, res) => {
    try {
        const { name, email, password, phone, address, gender, answer } = req.body
        const isUserExists = await Users.findOne({ email })

        if (isUserExists) {
            res.status(404).send({ success: false, message: 'Error', err: 'user already exists' })
        }
        else {
            const hashedPassword = await hashPassword(password)
            const newUser = await new Users({ name, email, password: hashedPassword, phone, address, gender, answer })
            const user = await newUser.save()
            res.status(200).send({ success: true, user:{
                    name: newUser.name,
                    email: newUser.email,
                    phone: newUser.phone,
                    address: newUser.address,
                    answer: newUser.answer
            } })
        }

    } catch (error) {
        res.status(404).send({ success: false, message: 'Error', err: error.message })
    }
}

module.exports = { getUsers, getUser, login, register }