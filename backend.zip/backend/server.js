const express = require('express')
const app = express()
require('./DB/connection')

const cors = require('cors')
app.use(cors())
app.use(express.json())


require('dotenv').config()
const PORT = process.env.PORT

const userRouter = require('./Routes/user')
app.use('/api/v1/auth', userRouter)

const categoryRouter = require('./Routes/category')
app.use('/api/v1/category', categoryRouter)

const productRouter = require('./Routes/product')
app.use('/api/v1/product', productRouter)

app.listen(PORT, () => {
    console.log(`Server is listening on PORT ${PORT}`)
})
